


$(document).ready(function(){

  // Make it easier to select a radio box
  $('.td_radio').on('click', function(){
    $(this).find('input').prop("checked", true);

  });
});
